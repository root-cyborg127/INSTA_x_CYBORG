#Importing Modules
import requests

#Importing Mi Func...
from FunctionData.somefun import clear
from MokupData.mokupfun import *
from BotData.MainBot import MainBot

#Men@s
KMFstatus = ("online")
# KMFstatuschecker = requests.get('https://docs.google.com/spreadsheets/d/1oCfdK7Rl3EYNAKh7BHbc30S8fToq8YHMmdRxz_metMQ/edit?usp=sharing')

#Program Started
clear()
INSTAXCYBORG()
# if KMFstatus in KMFstatuschecker.text:
MainBot()
    
# else:
    # OFFLINE()
    # DONATE()