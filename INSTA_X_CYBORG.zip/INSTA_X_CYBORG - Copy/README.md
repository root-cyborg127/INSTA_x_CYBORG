![kmfbanner](https://user-images.githubusercontent.com/58104674/95757141-60145280-0cc4-11eb-814f-6624d45dc077.jpg)
# KMF_BOT ![Version](https://img.shields.io/badge/Version-3.5.1-green)
---
### Table of Contents
You're sections headers will be used to reference location of destination.

- [Description](#description)
- [How To Use](#how-to-use)
- [License](#license)
- [Author Info](#author-info)
- [Donate](#donate)

---

## Description

KMF BOT is an Instagram bot that automates some options for you, there are seven options available now. You can run the bot and it will start building real, organic followers to your account.
With TemHunter, you can get average 150-200 followers every day. yet our BOT not violate any of Instagram's rules, so you don't have to worry about getting ACTION BLOCK !

[Completely Free BOT]

#### Features

- TeamHunter
- Masslooker
- Re-Hashtag
- Infinity-Feedliker
- Inshackle
- Unfollow Non-Followers
- Profile-Scraper
---

## How To Use

#### Installation 
```
git clone https://github.com/ananthuganesh/KMF_BOT.git
```
```
cd KMF_BOT
```
```
pip install -r requirements.txt
```
```
python main.py
```

---
## License

MIT License

Copyright (c) [2020] [Ananthu Ganesh]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---
## Author Info

- [Whatsapp Group](https://chat.whatsapp.com/HodrQitZNwX4tJoAd46OS4)
- [Telegram Channel](https://t.me/KMFBOT_OFFICIAL)
---

## Donate

If you love our work, Consider donating. 

[PayPal](paypalme/ananthuganesh)
